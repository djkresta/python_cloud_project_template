# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['fastapi_dev']

package_data = \
{'': ['*']}

install_requires = \
['fastapi', 'fastapi-utils', 'pydantic[dotenv]==1.8.1']

setup_kwargs = {
    'name': 'fastapi-dev',
    'version': '0.9.0.dev0',
    'description': '',
    'long_description': None,
    'author': 'OmniVector Solutions',
    'author_email': 'info@omnivector.solutions',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
